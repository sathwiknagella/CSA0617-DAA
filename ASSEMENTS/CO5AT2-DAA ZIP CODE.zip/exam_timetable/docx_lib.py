from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"

def set_font(style, size, bold=None):
    style.font.name = FONT; style.font.size = Pt(size); style.font.color.rgb = RGBColor(0, 0, 0)
    if bold is not None: style.font.bold = bold
    rpr = style.element.get_or_add_rPr(); rf = rpr.find(qn("w:rFonts"))
    if rf is None: rf = OxmlElement("w:rFonts"); rpr.append(rf)
    for a in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"): rf.set(qn(a), FONT)
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]

def fld(par, instr, size=12):
    for t, txt in (("begin", None), (None, instr), ("end", None)):
        r = par.add_run(); r.font.name = FONT; r.font.size = Pt(size)
        if t:
            c = OxmlElement("w:fldChar"); c.set(qn("w:fldCharType"), t); r._r.append(c)
        else:
            i = OxmlElement("w:instrText"); i.set(qn("xml:space"), "preserve"); i.text = txt; r._r.append(i)

def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), color); tcPr.append(sh)

def cell_margins(table, top=40, bottom=40, left=80, right=80):
    tblPr = table._tbl.tblPr; m = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        e = OxmlElement(f"w:{k}"); e.set(qn("w:w"), str(v)); e.set(qn("w:type"), "dxa"); m.append(e)
    tblPr.append(m)

class Report:
    def __init__(self):
        d = self.d = Document()
        s = d.sections[0]
        s.page_width, s.page_height = Cm(21.0), Cm(29.7)
        s.left_margin = s.right_margin = Cm(2.54); s.top_margin = s.bottom_margin = Cm(2.54)
        st = d.styles
        set_font(st["Normal"], 12)
        pf = st["Normal"].paragraph_format; pf.line_spacing = 1.15; pf.space_after = Pt(6); pf.space_before = Pt(0)
        pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        for name, size in (("Heading 1", 16), ("Heading 2", 14)):
            set_font(st[name], size, True)
            p = st[name].paragraph_format; p.alignment = WD_ALIGN_PARAGRAPH.LEFT; p.line_spacing = 1.15
            p.space_before = Pt(14 if size == 16 else 10); p.space_after = Pt(6); p.keep_with_next = True
        self.fig = self.tab = 0
        self.heads = []

    # ----- text -----
    def p(self, text="", bold=False, italic=False, align=None, size=12, after=None, keep=False):
        par = self.d.add_paragraph()
        self._runs(par, text, bold, italic, size)
        if align is not None: par.alignment = align
        if after is not None: par.paragraph_format.space_after = Pt(after)
        if keep: par.paragraph_format.keep_with_next = True
        return par

    def _runs(self, par, text, bold=False, italic=False, size=12):
        # **bold** inline markup
        parts = text.split("**")
        for i, t in enumerate(parts):
            if not t: continue
            r = par.add_run(t); r.font.name = FONT; r.font.size = Pt(size); r.bold = bold or (i % 2 == 1); r.italic = italic

    def h1(self, text):
        h = self.d.add_paragraph(style="Heading 1"); h.add_run(text.upper()); self.heads.append((1, text.upper()))
        if len(self.heads) > 1 and self.pagebreak_h1: h.paragraph_format.page_break_before = True
        return h
    pagebreak_h1 = True

    def h2(self, text):
        h = self.d.add_paragraph(style="Heading 2"); h.add_run(text); self.heads.append((2, text)); return h

    def bullets(self, items, size=12):
        for it in items:
            par = self.d.add_paragraph(); par.paragraph_format.left_indent = Cm(1.0); par.paragraph_format.first_line_indent = Cm(-0.5)
            par.paragraph_format.space_after = Pt(3)
            self._runs(par, "•  " + it, size=size)
        self.d.paragraphs[-1].paragraph_format.space_after = Pt(8)

    def numbered(self, items):
        for i, it in enumerate(items, 1):
            par = self.d.add_paragraph(); par.paragraph_format.left_indent = Cm(1.0); par.paragraph_format.first_line_indent = Cm(-0.7)
            par.paragraph_format.space_after = Pt(3); self._runs(par, f"{i}.  " + it)
        self.d.paragraphs[-1].paragraph_format.space_after = Pt(8)

    # ----- figure/table -----
    def figure(self, path, caption, width=14.0):
        self.fig += 1
        par = self.d.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.CENTER; par.paragraph_format.keep_with_next = True
        par.paragraph_format.space_before = Pt(6); par.paragraph_format.space_after = Pt(2)
        par.add_run().add_picture(path, width=Cm(width))
        self.p(f"Figure {self.fig}: {caption}", italic=True, align=WD_ALIGN_PARAGRAPH.CENTER, size=11, after=10)

    def table(self, header, rows, widths, caption, size=11, align_center_cols=(), bold_last=False):
        self.tab += 1
        c = self.p(f"Table {self.tab}: {caption}", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, size=11, after=4, keep=True)
        c.paragraph_format.space_before = Pt(6)
        t = self.d.add_table(rows=1, cols=len(header)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False; cell_margins(t)
        def fill(cell, text, bold=False, center=False, w=None):
            cell.text = ""; par = cell.paragraphs[0]; par.paragraph_format.line_spacing = 1.0
            par.paragraph_format.space_after = Pt(0); par.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
            self._runs(par, str(text), bold=bold, size=size)
            if w: cell.width = Cm(w)
        for i, h in enumerate(header):
            fill(t.rows[0].cells[i], h, True, True, widths[i]); shade(t.rows[0].cells[i], "D9D9D9")
        trPr = t.rows[0]._tr.get_or_add_trPr(); th = OxmlElement("w:tblHeader"); th.set(qn("w:val"), "true"); trPr.append(th)
        for ri, row in enumerate(rows):
            cells = t.add_row().cells
            cs = cells[0]._tc.getparent()
            cant = OxmlElement("w:cantSplit"); cant.set(qn("w:val"), "true"); cs.get_or_add_trPr().append(cant)
            for i, v in enumerate(row):
                fill(cells[i], v, bold=(bold_last and ri == len(rows) - 1), center=(i in align_center_cols), w=widths[i])
        self.p("", after=6)
        return t

    def code(self, title, lines, size=11):
        """lines: list of (indent, text)"""
        self.tab += 0
        self.p(title, bold=True, size=11, after=3, keep=True)
        t = self.d.add_table(rows=1, cols=1); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER; cell_margins(t, 60, 60, 120, 120)
        cell = t.rows[0].cells[0]; cell.width = Cm(15.8); cell.text = ""
        first = True
        for n, (ind, txt) in enumerate(lines, 1):
            par = cell.paragraphs[0] if first else cell.add_paragraph(); first = False
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT; par.paragraph_format.line_spacing = 1.0; par.paragraph_format.space_after = Pt(1)
            par.paragraph_format.left_indent = Cm(0.9 + 0.55 * ind); par.paragraph_format.first_line_indent = Cm(-0.9)
            r = par.add_run(f"{n:>2}.  "); r.font.size = Pt(size); r.font.name = FONT
            self._runs(par, txt, size=size)
        self.p("", after=6)

    # ----- sections / footer -----
    def footer_pagenum(self, section, fmt=None, start=None, blank=False):
        section.footer.is_linked_to_previous = False
        for p in section.footer.paragraphs:
            for r in list(p.runs): r._r.getparent().remove(r._r)
        par = section.footer.paragraphs[0]; par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if not blank: fld(par, " PAGE ", 12)
        sp = section._sectPr; pg = sp.find(qn("w:pgNumType"))
        if pg is None: pg = OxmlElement("w:pgNumType"); sp.append(pg)
        if fmt: pg.set(qn("w:fmt"), fmt)
        if start is not None: pg.set(qn("w:start"), str(start))

    def new_section(self):
        return self.d.add_section(WD_SECTION.NEW_PAGE)
