"""Examination timetabling: backtracking (feasibility) and branch and bound (soft constraint)."""
from itertools import product

COURSES = {"C1": ("Design and Analysis of Algorithms", 120), "C2": ("Operating Systems", 90),
           "C3": ("Database Management Systems", 110), "C4": ("Computer Networks", 60),
           "C5": ("Java Programming", 150), "C6": ("Discrete Mathematics", 80),
           "C7": ("Artificial Intelligence", 40), "C8": ("Cloud Computing", 70)}
CLASH_PAIRS = [("C1","C2"),("C1","C3"),("C2","C3"),("C1","C5"),("C3","C5"),("C2","C4"),("C4","C6"),
               ("C5","C6"),("C6","C7"),("C7","C8"),("C3","C8"),("C5","C8"),("C1","C6")]
HALLS = {"A": 160, "B": 120}
SLOTS = ["S1", "S2", "S3", "S4"]
DAY = {"S1": 1, "S2": 1, "S3": 2, "S4": 2}

SIZE = {c: v[1] for c, v in COURSES.items()}
ADJ = {c: set() for c in COURSES}
for a, b in CLASH_PAIRS:
    ADJ[a].add(b); ADJ[b].add(a)
DEG = {c: len(ADJ[c]) for c in COURSES}
# order: largest degree first (most constrained), ties by larger enrolment
ORDER = sorted(COURSES, key=lambda c: (-DEG[c], -SIZE[c]))

def room_assign(exams):
    """Return {exam: hall} for one slot or None. Largest exam goes to the largest hall."""
    halls = sorted(HALLS.items(), key=lambda h: -h[1])
    if len(exams) > len(halls): return None
    res = {}
    for e, (h, cap) in zip(sorted(exams, key=lambda c: -SIZE[c]), halls):
        if SIZE[e] > cap: return None
        res[e] = h
    return res

def backtrack(order, slots, log=None):
    asg = {}; stats = {"nodes": 0, "rejects": 0, "backtracks": 0}
    def rec(i, depth):
        if i == len(order): return True
        e = order[i]
        for s in slots:
            stats["nodes"] += 1
            clash = [n for n in ADJ[e] if asg.get(n) == s]
            if clash:
                stats["rejects"] += 1
                if log is not None: log.append((depth, e, s, "reject", f"H1 clash with {clash[0]}"))
                continue
            here = [x for x, t in asg.items() if t == s] + [e]
            if room_assign(here) is None:
                stats["rejects"] += 1
                why = "H2 no free hall (both halls busy)" if len(here) > len(HALLS) else "H2 capacity"
                if log is not None: log.append((depth, e, s, "reject", why))
                continue
            asg[e] = s
            if log is not None: log.append((depth, e, s, "assign", ""))
            if rec(i + 1, depth + 1): return True
            del asg[e]; stats["backtracks"] += 1
            if log is not None: log.append((depth, e, s, "undo", "subtree failed"))
        return False
    ok = rec(0, 0)
    return ok, dict(asg), stats

def branch_and_bound():
    best = {"pen": 10**9, "asg": None, "sols": []}
    asg = {}; st = {"nodes": 0, "pruned_bound": 0, "pruned_hard": 0, "leaves": 0, "improve": []}
    def rec(i, pen):
        if pen > best["pen"]: st["pruned_bound"] += 1; return
        if pen == best["pen"] and best["asg"] is not None and i < len(ORDER):
            st["pruned_bound"] += 1; return
        if i == len(ORDER):
            st["leaves"] += 1
            if pen < best["pen"]:
                best["pen"] = pen; best["asg"] = dict(asg); st["improve"].append((pen, dict(asg)))
            return
        e = ORDER[i]
        for s in SLOTS:
            st["nodes"] += 1
            if any(asg.get(n) == s for n in ADJ[e]): st["pruned_hard"] += 1; continue
            here = [x for x, t in asg.items() if t == s] + [e]
            if room_assign(here) is None: st["pruned_hard"] += 1; continue
            add = sum(1 for n in ADJ[e] if n in asg and DAY[asg[n]] == DAY[s])
            asg[e] = s; rec(i + 1, pen + add); del asg[e]
    rec(0, 0)
    return best, st

def penalty(a):
    return sum(1 for x, y in CLASH_PAIRS if DAY[a[x]] == DAY[a[y]])

def exhaustive():
    sols = []
    for combo in product(SLOTS, repeat=len(ORDER)):
        a = dict(zip(ORDER, combo))
        if any(a[x] == a[y] for x, y in CLASH_PAIRS): continue
        ok = True
        for s in SLOTS:
            if room_assign([e for e in a if a[e] == s]) is None: ok = False; break
        if ok: sols.append(a)
    return sols

if __name__ == "__main__":
    print("deg", DEG, "order", ORDER)
    log = []
    ok, a, st = backtrack(ORDER, SLOTS, log)
    for l in log: print(l)
    print(ok, a, st, penalty(a))
    for k in (3,):
        log3 = []
        print("3 slots", backtrack(ORDER, SLOTS[:3], log3)[::2], len(log3))
    print("sum", sum(SIZE.values()))
    b, s = branch_and_bound(); print(b["pen"], b["asg"], {k: v for k, v in s.items() if k != "improve"}, [p for p, _ in s["improve"]])
    sols = exhaustive(); print(len(sols), sorted(set(penalty(x) for x in sols)))
    best = min(sols, key=penalty); print(best, penalty(best), sum(1 for x in sols if penalty(x) == penalty(best)))
    print("chi lower bound / 3 colour feasible ignoring rooms:",
          any(all(a[x]!=a[y] for x,y in CLASH_PAIRS) for a in (dict(zip(ORDER,c)) for c in product(SLOTS[:3],repeat=8))))
