import math, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, Ellipse, Rectangle
from collections import Counter
from solver import *

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"], "font.size": 10})
SH = {"S1": "#ffffff", "S2": "#d9d9d9", "S3": "#a6a6a6", "S4": "#707070"}
def save(name): plt.savefig(f"figures/{name}.png", dpi=200, bbox_inches="tight"); plt.close()

POS = {}
for i, c in enumerate(COURSES):
    ang = math.pi / 2 - 2 * math.pi * i / 8
    POS[c] = (math.cos(ang), math.sin(ang))

def graph(fill=None, bold=None, title=None, labels=None):
    fig, ax = plt.subplots(figsize=(5.2, 5.2)); ax.axis("off"); ax.set_aspect("equal")
    for a, b in CLASH_PAIRS:
        (x1, y1), (x2, y2) = POS[a], POS[b]
        hot = bold and ((a, b) in bold)
        ax.plot([x1, x2], [y1, y2], color="black", lw=2.6 if hot else 0.9, ls="-" if (hot or not bold) else "--", zorder=1)
    for c, (x, y) in POS.items():
        col = fill[c] if fill else "white"
        ax.add_patch(plt.Circle((x, y), 0.14, fc=col, ec="black", lw=1.3, zorder=2))
        ax.text(x, y, c, ha="center", va="center", fontsize=10, color="white" if col == "#707070" else "black", zorder=3, fontweight="bold")
        ax.text(x * 1.3, y * 1.3, labels[c] if labels else f"{SIZE[c]}", ha="center", va="center", fontsize=9)
    ax.set_xlim(-1.5, 1.5); ax.set_ylim(-1.5, 1.5)
    return ax

graph(); save("f01_conflict_graph")
ok, a4, _ = backtrack(ORDER, SLOTS)
graph({c: SH[a4[c]] for c in COURSES}, labels={c: a4[c] for c in COURSES}); save("f08_colored_graph")

# enrolment
fig, ax = plt.subplots(figsize=(6, 3)); cs = list(COURSES)
ax.bar(cs, [SIZE[c] for c in cs], color="#bfbfbf", edgecolor="black")
for i, c in enumerate(cs): ax.text(i, SIZE[c] + 2, SIZE[c], ha="center")
ax.axhline(120, ls="--", color="black", lw=1); ax.text(7.45, 122, "Hall B (120)", ha="right", fontsize=9)
ax.axhline(160, ls=":", color="black", lw=1); ax.text(7.45, 162, "Hall A (160)", ha="right", fontsize=9)
ax.set_ylabel("Registered students"); ax.set_ylim(0, 180); save("f02_enrolment")

# 3-slot capacity
fig, ax = plt.subplots(figsize=(6.4, 3.4)); ax.axis("off")
for s in range(3):
    for h in range(2):
        ax.add_patch(Rectangle((s * 1.6, 1.2 - h * 1.1), 1.4, 0.9, fc="#d9d9d9", ec="black"))
        ax.text(s * 1.6 + 0.7, 1.65 - h * 1.1, f"S{s+1} / Hall {'AB'[h]}", ha="center", va="center", fontsize=9)
for i, c in enumerate(COURSES):
    ax.add_patch(Rectangle((i * 0.6, -0.5), 0.52, 0.5, fc="white", ec="black")); ax.text(i * 0.6 + 0.26, -0.25, c, ha="center", va="center", fontsize=9)
ax.text(2.4, 2.3, "6 room-slots available (3 slots x 2 halls)", ha="center", fontsize=10, fontweight="bold")
ax.text(2.4, -0.8, "8 exams to place  >  6 room-slots  =>  infeasible (pigeonhole)", ha="center", fontsize=10, fontweight="bold")
ax.set_xlim(-0.1, 4.9); ax.set_ylim(-1, 2.5); save("f03_pigeonhole")

# flowchart helper
def flow(nodes, edges, size, name):
    fig, ax = plt.subplots(figsize=size); ax.axis("off")
    for k, (x, y, w, h, t, kind) in nodes.items():
        if kind == "d":
            ax.add_patch(Polygon([(x, y + h / 2), (x + w / 2, y), (x, y - h / 2), (x - w / 2, y)], fc="white", ec="black", lw=1.2))
        else:
            ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0,rounding_size=%s" % (0.2 if kind == "t" else 0.02), fc="#e6e6e6" if kind == "t" else "white", ec="black", lw=1.2))
        ax.text(x, y, t, ha="center", va="center", fontsize=8.5)
    for a, b, lab, pa, pb in edges:
        xa, ya = pa; xb, yb = pb
        ax.annotate("", xy=(xb, yb), xytext=(xa, ya), arrowprops=dict(arrowstyle="->", lw=1.1, shrinkA=0, shrinkB=0))
        if lab: ax.text((xa + xb) / 2 + 0.08, (ya + yb) / 2 + 0.08, lab, fontsize=8.5, fontweight="bold")
    ax.autoscale(); ax.set_aspect("equal"); save(name)

def vflow(steps, name, size=(5, 8), w=3.4):
    nodes = {}; edges = []; y = 0; gap = 0.45; notes = []
    for i, st_ in enumerate(steps):
        t, kind = st_[0], st_[1]
        hh = 1.25 if kind == "d" else 0.62
        nodes[i] = (0, y, w + (0.5 if kind == "d" else 0), hh, t, kind); y -= (hh + gap)
    for i in range(len(steps) - 1):
        top = nodes[i]; nx = nodes[i + 1]
        lab = steps[i][2] if len(steps[i]) > 2 else ""
        edges.append((i, i + 1, lab, (0, top[1] - top[3] / 2), (0, nx[1] + nx[3] / 2)))
    fig, ax = plt.subplots(figsize=size); ax.axis("off")
    flow_draw(ax, nodes, edges)
    for i, st_ in enumerate(steps):
        if len(st_) > 3:
            x, yy, ww, hh, _, _ = nodes[i]
            ax.annotate("", xy=(ww / 2 + 1.1, yy), xytext=(ww / 2, yy), arrowprops=dict(arrowstyle="->", lw=1.1))
            ax.text(ww / 2 + 1.2, yy, st_[3], fontsize=8.5, va="center", fontweight="bold")
    ax.autoscale(); ax.set_aspect("equal"); save(name)

def flow_draw(ax, nodes, edges):
    for k, (x, y, w, h, t, kind) in nodes.items():
        if kind == "d":
            ax.add_patch(Polygon([(x, y + h / 2), (x + w / 2, y), (x, y - h / 2), (x - w / 2, y)], fc="white", ec="black", lw=1.2))
        else:
            ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0,rounding_size=%s" % (0.2 if kind == "t" else 0.02), fc="#e6e6e6" if kind == "t" else "white", ec="black", lw=1.2))
        ax.text(x, y, t, ha="center", va="center", fontsize=8.5)
    for a, b, lab, pa, pb in edges:
        ax.annotate("", xy=pb, xytext=pa, arrowprops=dict(arrowstyle="->", lw=1.1, shrinkA=0, shrinkB=0))
        if lab: ax.text(pa[0] + 0.1, (pa[1] + pb[1]) / 2, lab, fontsize=8.5, fontweight="bold", va="center")

vflow([("START: Backtrack(i = 0)", "t"), ("i = n ?  (all exams placed)", "d", "NO", "YES: return SUCCESS"),
       ("e = order[i]; s = first slot", "p"), ("Clash with exam already in s? (H1)", "d", "NO", "YES: next slot"),
       ("Hall allocation possible in s? (H2)", "d", "YES", "NO: next slot"), ("Assign e to s; call Backtrack(i + 1)", "p"),
       ("Sub-call succeeded?", "d", "NO: undo e", "YES: return SUCCESS"), ("Slots left? if none return FAILURE", "p"), ("END", "t")],
      "f04_flow_backtrack", (6.2, 9))

vflow([("START: candidate exam e, slot s", "t"), ("Collect exams in s, add e", "p"), ("More exams than halls?", "d", "NO", "YES: infeasible"),
       ("Sort exams and halls by size (descending)", "p"), ("Pair k-th exam with k-th hall", "p"),
       ("Any exam larger than its hall?", "d", "NO", "YES: infeasible"), ("Return hall map (feasible)", "t")], "f05_flow_room", (5.8, 7.2))

vflow([("START: B&B(i, penalty)", "t"), ("penalty >= best ?", "d", "NO", "YES: prune, return"), ("i = n ? (leaf)", "d", "NO", "YES: record if better"),
       ("For each slot s: check H1 and H2", "p"), ("Add same-day clashing neighbours", "p"),
       ("Assign e to s; B&B(i+1, penalty+added)", "p"), ("Undo assignment; try next slot", "p"),
       ("All slots tried: return", "p"), ("END: best timetable is optimal", "t")], "f13_flow_bb", (6.2, 9))

vflow([("Input: 300 courses, enrolments, clash graph, halls", "t"), ("Pre-process: degree, clique and room-slot bounds", "p"),
       ("Construct: DSATUR colouring gives initial slots", "p"), ("Allocate halls per slot (matching / bin packing)", "p"),
       ("Repair: Kempe-chain moves for hard violations", "p"), ("Improve: simulated annealing / tabu on penalty", "p"),
       ("Polish: exact B&B or CP-SAT on sub-problems", "p"), ("Validate H1-H3 and publish timetable", "t")], "f14_pipeline", (5.6, 8.4), w=4.8)

# search tree matrix
log = []; backtrack(ORDER, SLOTS, log)
fig, ax = plt.subplots(figsize=(6.8, 4.6)); ax.axis("off")
ax.text(0, 8.7, "Exam", fontweight="bold", ha="center")
for j, s in enumerate(SLOTS): ax.text(1.7 + j * 1.6, 8.7, s, fontweight="bold", ha="center")
res = {}
for d, e, s, kind, why in log:
    if kind in ("reject", "assign"): res[(e, s)] = (kind, why)
for i, e in enumerate(ORDER):
    y = 7.7 - i
    ax.text(0, y, e, ha="center", va="center", fontweight="bold")
    for j, s in enumerate(SLOTS):
        x = 1.7 + j * 1.6
        if (e, s) not in res:
            ax.add_patch(Rectangle((x - 0.75, y - 0.4), 1.5, 0.8, fc="white", ec="#999999", ls=":")); ax.text(x, y, "not tried", ha="center", va="center", fontsize=7, color="#666666"); continue
        k, why = res[(e, s)]
        if k == "assign":
            ax.add_patch(Rectangle((x - 0.75, y - 0.4), 1.5, 0.8, fc="#bfbfbf", ec="black", lw=1.6)); ax.text(x, y, "ASSIGN", ha="center", va="center", fontweight="bold", fontsize=8)
        else:
            ax.add_patch(Rectangle((x - 0.75, y - 0.4), 1.5, 0.8, fc="white", ec="black")); ax.text(x, y, "X " + (why.replace("H1 clash with ", "clash ") if "H1" in why else "no hall"), ha="center", va="center", fontsize=8)
ax.set_xlim(-0.6, 8.2); ax.set_ylim(-0.6, 9.2); save("f06_search_tree")

# timetable grid for 4 slots, and best timetable
def grid(a, name):
    fig, ax = plt.subplots(figsize=(6.6, 3)); ax.axis("off")
    for j, s in enumerate(SLOTS):
        ax.add_patch(Rectangle((1.2 + j * 1.8, 2.6), 1.8, 0.7, fc="#d9d9d9", ec="black"))
        ax.text(2.1 + j * 1.8, 2.95, f"{s}  ({'Day 1' if DAY[s]==1 else 'Day 2'} {'FN' if s in ('S1','S3') else 'AN'})", ha="center", va="center", fontsize=8.5, fontweight="bold")
    for i, h in enumerate("AB"):
        y = 1.8 - i * 0.9
        ax.add_patch(Rectangle((0, y), 1.2, 0.9, fc="#d9d9d9", ec="black")); ax.text(0.6, y + 0.45, f"Hall {h}\n({HALLS[h]})", ha="center", va="center", fontsize=8.5, fontweight="bold")
        for j, s in enumerate(SLOTS):
            ex = [e for e in a if a[e] == s]; r = room_assign(ex); e = [x for x in ex if r[x] == h]
            ax.add_patch(Rectangle((1.2 + j * 1.8, y), 1.8, 0.9, fc="white", ec="black"))
            if e: ax.text(2.1 + j * 1.8, y + 0.45, f"{e[0]} ({SIZE[e[0]]})", ha="center", va="center", fontsize=9)
    ax.set_xlim(-0.1, 8.5); ax.set_ylim(0.8, 3.4); save(name)
grid(a4, "f07_timetable_first")
best, st = branch_and_bound(); grid(best["asg"], "f09_timetable_best")

# search space bar
fig, ax = plt.subplots(figsize=(6.4, 3.2))
labs = ["Slot assignments\n4^8", "Slot x hall\n8^8", "Feasible\n(exhaustive)", "B&B nodes", "Backtracking\ncandidates"]
vals = [4**8, 8**8, 216, st["nodes"], 20]
ax.bar(labs, vals, color="#bfbfbf", edgecolor="black"); ax.set_yscale("log"); ax.set_ylabel("Count (log scale)")
for i, v in enumerate(vals): ax.text(i, v * 1.3, f"{v:,}", ha="center", fontsize=9)
ax.set_ylim(1, 1e9); plt.xticks(fontsize=8); save("f10_search_space")

# penalty distribution
sols = exhaustive(); cnt = Counter(penalty(s) for s in sols)
fig, ax = plt.subplots(figsize=(5.4, 3)); ks = sorted(cnt)
ax.bar([str(k) for k in ks], [cnt[k] for k in ks], color="#bfbfbf", edgecolor="black")
for i, k in enumerate(ks): ax.text(i, cnt[k] + 1, cnt[k], ha="center")
ax.set_xlabel("Same-day clashing pairs (penalty)"); ax.set_ylabel("Feasible timetables"); save("f11_penalty_dist")

# growth
fig, ax = plt.subplots(figsize=(5.6, 3.2)); ns = list(range(4, 31))
ax.plot(ns, [4**n for n in ns], "k-", label="k^n  (k = 4)"); ax.plot(ns, [n**3 for n in ns], "k--", label="n^3 (polynomial)")
ax.set_yscale("log"); ax.set_xlabel("Number of courses n"); ax.set_ylabel("Operations (log scale)"); ax.legend(); ax.grid(alpha=0.3); save("f12_growth")

# complexity classes
fig, ax = plt.subplots(figsize=(6, 3.6)); ax.axis("off")
ax.add_patch(Ellipse((2.4, 1.6), 4.6, 3.0, fc="white", ec="black", lw=1.4)); ax.add_patch(Ellipse((1.5, 1.4), 1.8, 1.2, fc="#e6e6e6", ec="black"))
ax.add_patch(Ellipse((3.2, 1.3), 2.0, 1.3, fc="#bfbfbf", ec="black"))
ax.add_patch(Ellipse((4.3, 1.5), 3.6, 2.3, fc="none", ec="black", ls="--", lw=1.4))
ax.text(1.5, 1.4, "P", ha="center", fontweight="bold"); ax.text(3.2, 1.3, "NP-Complete\n(timetable decision,\n3-colouring)", ha="center", fontsize=8.5)
ax.text(1.6, 2.8, "NP", fontweight="bold"); ax.text(5.6, 0.45, "NP-Hard\n(optimisation\nversion)", ha="center", fontsize=8.5)
ax.set_xlim(0, 6.5); ax.set_ylim(0, 3.4); save("f15_classes")

# best timetable graph with day shading
pairs_same = {(x, y) for x, y in CLASH_PAIRS if DAY[best["asg"][x]] == DAY[best["asg"][y]]}
graph({c: ("#d9d9d9" if DAY[best["asg"][c]] == 1 else "#a6a6a6") for c in COURSES}, bold=pairs_same, labels={c: best["asg"][c] for c in COURSES}); save("f16_best_graph")
print("done")
