Examination Timetabling (CSA06 CO5)
python3 solver.py          # backtracking trace, branch and bound, exhaustive check
python3 make_figures.py    # needs matplotlib
python3 build_report.py    # needs python-docx, LibreOffice (page numbers in TOC)
