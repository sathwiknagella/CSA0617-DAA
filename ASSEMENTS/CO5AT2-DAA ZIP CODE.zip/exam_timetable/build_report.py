import sys, subprocess, re, json, os
from collections import Counter
from docx_lib import *
from solver import *

NAME, REG = "Nagella Sathwik", "192525077"
F = lambda n: f"figures/{n}.png"
J = WD_ALIGN_PARAGRAPH.JUSTIFY; C = WD_ALIGN_PARAGRAPH.CENTER

# ---------- computed results ----------
log4 = []; ok4, a4, st4 = backtrack(ORDER, SLOTS, log4)
log3 = []; ok3, a3, st3 = backtrack(ORDER, SLOTS[:3], log3)
best, bb = branch_and_bound()
sols = exhaustive(); dist = Counter(penalty(s) for s in sols)
BA = best["asg"]
def slot_rooms(a, s):
    ex = [e for e in a if a[e] == s]; r = room_assign(ex); return ", ".join(f"{e} (Hall {r[e]})" for e in sorted(ex, key=lambda c: -SIZE[c]))
def hall_of(a, e): return room_assign([x for x in a if a[x] == a[e]])[e]
maxdepth3 = max(d for d, e, s, k, w in log3 if k == "assign") + 1
def sci(x):
    import math
    e = int(math.log10(x)); return f"{x / 10**e:.2f} x 10^{e}"

def build(toc_pages):
    R = Report(); d = R.d
    # ================= TITLE PAGE =================
    for t, sz, b, after in (("SAVEETHA SCHOOL OF ENGINEERING", 16, True, 2), ("SIMATS ENGINEERING", 14, True, 2),
                            ("Department of Computer Science and Engineering", 14, True, 40)):
        R.p(t, bold=b, size=sz, align=C, after=after)
    R.p("CSA06 – DESIGN AND ANALYSIS OF ALGORITHMS", bold=True, size=14, align=C, after=6)
    R.p("CO5 – Constraint-Based Problem Solving", size=12, align=C, after=60)
    R.p("EXAMINATION TIMETABLING AT A UNIVERSITY", bold=True, size=20, align=C, after=8)
    R.p("A Backtracking and Branch-and-Bound Solution with Complexity Analysis", size=14, align=C, after=70)
    rows = [("Student Name", NAME), ("Registration Number", REG), ("Course Code and Name", "CSA06 – Design and Analysis of Algorithms"),
            ("Assessment", "CO5 – Constraint-Based Problem Solving"), ("Duration / Mode", "1 Week / Individual"), ("Academic Year", "2026–2027")]
    t = d.add_table(rows=0, cols=2); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER; cell_margins(t, 70, 70, 100, 100)
    for a, b in rows:
        c = t.add_row().cells; c[0].width = Cm(5.5); c[1].width = Cm(10)
        for cell, txt, bd in ((c[0], a, True), (c[1], b, False)):
            cell.text = ""; par = cell.paragraphs[0]; par.paragraph_format.space_after = Pt(0); par.alignment = WD_ALIGN_PARAGRAPH.LEFT
            R._runs(par, txt, bold=bd, size=12)
        shade(c[0], "D9D9D9")
    R.p("", after=30)
    R.p("Submitted to the Examination Cell, Department of Computer Science and Engineering", size=12, align=C, after=0)
    R.footer_pagenum(d.sections[0], blank=True)

    # ================= DECLARATION + TOC =================
    s2 = R.new_section(); R.footer_pagenum(s2, fmt="lowerRoman", start=1)
    R.p("DECLARATION", bold=True, size=16, align=C, after=10)
    R.p(f"I, {NAME} (Reg. No. {REG}), certify that this submission is my original work and that I have adhered to the guidelines specified for this assessment. I understand that any violation of academic integrity rules will result in disciplinary action.")
    R.p("Signature of the Student: ____________________          Date: ______________", align=WD_ALIGN_PARAGRAPH.LEFT, after=14)
    R.p("ABSTRACT", bold=True, size=16, align=C, after=8)
    R.p("This report designs, analyses and evaluates an algorithmic solution to the end-semester examination timetabling problem of a university. Eight courses must be placed in four examination slots (two days, two sessions per day) using two halls of capacity 160 and 120, such that no two courses sharing a student are examined together, no hall is overloaded, and every examination is held exactly once. The problem is formalised as a constraint satisfaction problem and related to graph colouring. Necessary conditions are derived that prove, before any search, that three slots cannot suffice. A backtracking algorithm with a most-constrained-first ordering is specified and traced on the data; it finds a feasible timetable with 20 candidate checks instead of the 65,536 slot assignments of the full space. A branch-and-bound extension then minimises the number of clashing pairs written on the same day and proves that the minimum is three. Finally the report classifies the decision version as NP-Complete and the optimisation version as NP-Hard, and proposes a heuristic pipeline for scheduling 300 courses.")
    R.p("TABLE OF CONTENTS", bold=True, size=16, align=C, after=8).paragraph_format.page_break_before = True
    # TOC (field with cached result)
    sec = d.sections[-1]; width = sec.page_width - sec.left_margin - sec.right_margin
    heads = TOC_HEADS
    for i, (lvl, txt) in enumerate(heads):
        par = d.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.LEFT
        pf = par.paragraph_format; pf.left_indent = Cm(0 if lvl == 1 else 0.8); pf.space_after = Pt(2 if lvl == 2 else 3); pf.space_before = Pt(4 if lvl == 1 else 0)
        pf.tab_stops.add_tab_stop(width, WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
        if i == 0:
            for t_, x_ in (("begin", None), (None, ' TOC \\o "1-2" \\h \\z \\u '), ("separate", None)):
                r = par.add_run()
                if t_:
                    c = OxmlElement("w:fldChar"); c.set(qn("w:fldCharType"), t_); r._r.append(c)
                else:
                    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = x_; r._r.append(it)
        r = par.add_run(f"{txt}\t{toc_pages.get(txt, '')}"); r.font.name = FONT; r.font.size = Pt(12 if lvl == 1 else 11.5); r.bold = (lvl == 1)
        if i == len(heads) - 1:
            r2 = par.add_run(); c = OxmlElement("w:fldChar"); c.set(qn("w:fldCharType"), "end"); r2._r.append(c)

    # ================= BODY =================
    s3 = R.new_section(); R.footer_pagenum(s3, fmt="decimal", start=1)
    R.heads = []; R.pagebreak_h1 = False
    H1, H2, P, B = R.h1, R.h2, R.p, R.bullets

    H1("1. Introduction")
    H2("1.1 Background")
    P("Every semester a university must convert a list of courses, registrations and available rooms into a published examination schedule. A good schedule is one that students can actually sit: no student is asked to write two papers at the same time, no hall holds more candidates than it has seats, and the load on any one student is spread as evenly as possible. When the timetable is prepared by hand, the Examination Cell checks these conditions manually, course by course. For a handful of courses this is manageable; for a full university it is slow, error-prone and impossible to repeat quickly when a late registration changes the data.")
    P("Last semester the manual timetable of this university produced student clashes and overcrowded halls. The Controller of Examinations has therefore asked for an algorithmic solution and for an explanation of how the difficulty of the task grows with the number of courses. This report is that solution. It treats the timetable as a constraint satisfaction problem, solves it with systematic backtracking, improves it with branch and bound, and places the problem inside the theory of computational complexity.")
    H2("1.2 Objectives")
    B(["Define the examination timetabling problem precisely, in both its decision and optimisation versions, and relate it to graph colouring.",
       "Analyse how the clash constraint and the room constraints interact, derive necessary conditions that can prove infeasibility without search, and decide the order in which constraints and exams are processed.",
       "Design, specify and trace a complete backtracking algorithm on the eight-course data set, and decide whether three slots suffice.",
       "Classify the problem as NP, NP-Complete or NP-Hard and compare the full search space with the work actually performed.",
       "Extend the solution with branch and bound to minimise same-day clashes, justify its correctness, and describe a practical approach for 300 courses."])
    H2("1.3 Scope and Method")
    P("The report works strictly with the data supplied by the Examination Cell: eight courses with 720 registrations in total, thirteen clashing pairs, four slots and two halls per slot. All results quoted in the report were produced by a Python program (solver.py, supplied in the accompanying ZIP file) and cross-checked by an independent exhaustive enumeration of all 4^8 = 65,536 slot assignments. The report therefore contains no hand-waved numbers: every count of nodes, rejections, backtracks and timetables can be reproduced by running the code.")
    H2("1.4 Organisation of the Report")
    P("Section 2 defines the problem (Task a). Section 3 analyses and prioritises the constraints (Task b). Section 4 presents the backtracking design with pseudocode (Task c). Section 5 applies it to the data and answers the three-slot question (Task d). Section 6 classifies the complexity (Task e). Sections 7 and 8 improve the design with branch and bound and discuss scaling to 300 courses (Task f). Section 9 verifies the results and maps the report to the assessment rubric, and Section 10 concludes. Appendix A lists the complete three-slot trace and Appendix B describes the accompanying code.")

    H1("2. Problem Definition")
    H2("2.1 Problem Statement")
    P("The Examination Cell must schedule the end-semester examinations of eight courses within two days. Each day has two sessions, forenoon (FN) and afternoon (AN), giving four slots: S1 (Day 1 FN), S2 (Day 1 AN), S3 (Day 2 FN) and S4 (Day 2 AN). Two halls are available in every slot: Hall A with capacity 160 and Hall B with capacity 120. Table 1 lists the courses and their registrations, and Figure 1 shows the enrolments against the two hall capacities.")
    R.table(["Code", "Course", "Students", "Fits Hall A (160)", "Fits Hall B (120)"],
            [[c, COURSES[c][0], SIZE[c], "Yes", "Yes" if SIZE[c] <= 120 else "No"] for c in COURSES] + [["", "Total registrations", sum(SIZE.values()), "", ""]],
            [1.5, 6.5, 2.2, 2.9, 2.9], "Courses and registrations", align_center_cols=(0, 2, 3, 4), bold_last=True)
    R.figure(F("f02_enrolment"), "Enrolment of each course against hall capacities", 11.5)
    H2("2.2 Input")
    P("The input of the problem is the tuple (C, E, n, T, H, cap), described below.")
    B(["**C = {C1, ..., C8}**: the set of courses, with n = 8 and an enrolment n(c) for each course c (Table 1).",
       "**E**: the clash set, containing an unordered pair {a, b} whenever courses a and b have at least one common student. There are 13 such pairs: C1–C2, C1–C3, C2–C3, C1–C5, C3–C5, C2–C4, C4–C6, C5–C6, C6–C7, C7–C8, C3–C8, C5–C8 and C1–C6.",
       "**T = {S1, S2, S3, S4}**: the examination slots, with day(S1) = day(S2) = 1 and day(S3) = day(S4) = 2.",
       "**H = {A, B}**: the halls, with capacities cap(A) = 160 and cap(B) = 120, both available in every slot."])
    R.table(["Course", "Clashes with", "Degree", "Enrolment"],
            [[c, ", ".join(sorted(ADJ[c])), DEG[c], SIZE[c]] for c in COURSES], [2.2, 7.5, 2.4, 2.6], "Clash adjacency list of the eight courses", align_center_cols=(0, 2, 3))
    P("The adjacency list in Table 2 is the same information as the clash set E, organised per course. The sum of the degrees is 26, which is twice the number of clashing pairs (13), as required by the handshake lemma. The clash graph is shown in Figure 2: every vertex is a course, every edge a clash, and the number outside each vertex is its enrolment.")
    R.figure(F("f01_conflict_graph"), "Clash graph of the eight courses (vertex label outside = enrolment)", 9.5)
    H2("2.3 Decision Variables and Domains")
    P("For each course c the algorithm must decide when and where its examination is held. The decision variables and their domains are:")
    B(["**slot(c) ∈ T = {S1, S2, S3, S4}** for every course c. The domain of each variable has four values.",
       "**hall(c) ∈ H = {A, B}** for every course c, the hall in which the examination is held."])
    P("The pair (slot(c), hall(c)) is the complete decision for course c, so a candidate timetable is a function from the eight courses to the eight possible (slot, hall) cells. Because the hall decision is only constrained inside one slot, the search of Section 4 branches on slot(c) and decides hall(c) by a small feasibility check; this keeps the branching factor at four instead of eight.")
    H2("2.4 Hard Constraints")
    P("A timetable is feasible only if all three hard constraints hold.")
    B(["**H1 (clash):** for every clashing pair {a, b} in E, slot(a) ≠ slot(b). A student common to two courses can write only one paper at a time.",
       "**H2 (room):** every course c is held in exactly one hall with cap(hall(c)) ≥ n(c), and for any two distinct courses a ≠ b with slot(a) = slot(b) we have hall(a) ≠ hall(b). A hall holds at most one examination per slot.",
       "**H3 (completeness):** every examination is scheduled exactly once, so slot and hall are defined for all eight courses and for none twice."])
    H2("2.5 Soft Constraint")
    P("**S1** states that, as far as possible, students should not write two examinations on the same day. For a timetable τ define the penalty")
    P("penalty(τ) = | { {a, b} ∈ E : day(slot(a)) = day(slot(b)) } |,", align=C)
    P("the number of clashing pairs whose two examinations fall on the same day. Note that a pair in the same slot is already forbidden by H1, so the penalty counts pairs that are in different slots of the same day, for example S1 and S2. A timetable with penalty 0 would give every student at most one paper per day.")
    H2("2.6 Decision Version")
    P("**TIMETABLE-FEASIBILITY.** Instance: courses C with enrolments, clash set E, slots T, halls H with capacities. Question: does there exist an assignment of every course to a (slot, hall) pair that satisfies H1, H2 and H3? The answer is a yes/no value. For the supplied instance the answer is YES with k = 4 slots and NO with k = 3 slots.")
    H2("2.7 Optimisation Version")
    P("**TIMETABLE-MINIMISATION.** Among all assignments that satisfy H1, H2 and H3, find one that minimises penalty(τ). The output is a timetable and its penalty. A related decision version, **TIMETABLE-WITH-BUDGET**, asks whether a feasible timetable exists with penalty at most K; the optimisation problem can be solved by asking this question for K = 0, 1, 2, and so on.")
    H2("2.8 Relation to Graph Colouring")
    P("The clash set defines an undirected graph G = (V, E) with V = C. A feasible timetable ignoring rooms is exactly a proper vertex colouring of G in which the four slots are the colours: adjacent vertices (clashing courses) receive different colours. The minimum number of slots needed without room limits is the chromatic number χ(G). The room constraint H2 turns the problem into a colouring with an additional bound on the size and weight of each colour class: a class may hold at most two courses (two halls), and its members must fit the halls (the largest in Hall A, the other in Hall B). Table 3 summarises the correspondence.")
    R.table(["Timetabling concept", "Graph colouring concept"],
            [["Course", "Vertex"], ["Clashing pair (common student)", "Edge"], ["Examination slot", "Colour"], ["Feasible timetable (H1)", "Proper colouring"],
             ["Minimum slots without room limits", "Chromatic number χ(G)"], ["Hall limits (H2)", "Bounded colour-class size and capacity"],
             ["Courses in the same slot", "Colour class = independent set"], ["Same-day penalty (S1)", "Edges inside the merged colour pairs {S1,S2} and {S3,S4}"]],
            [7.8, 7.8], "Correspondence between timetabling and graph colouring")
    P("The clash graph contains triangles such as {C1, C2, C3}, {C1, C3, C5}, {C1, C5, C6} and {C3, C5, C8}, so at least three colours are needed, i.e. χ(G) ≥ 3. The graph has no clique of size four, and a 3-colouring exists when rooms are ignored. The room constraint is what pushes the requirement to four slots, as Section 3 shows.")
    H2("2.9 Assumptions")
    B(["Registrations are known and fixed; an exam occupies exactly one slot and one hall.",
       "Two halls are available in every slot and each hall can be used for one examination at a time (no hall sharing).",
       "The clash list is complete: two courses not listed have no common student.",
       "Slots on the same day are treated as equally burdensome; the penalty counts clashing pairs on the same day regardless of the slot positions."])

    H1("3. Constraint Analysis and Prioritisation")
    H2("3.1 Interaction of the Clash and Room Constraints")
    P("The clash constraint H1 is a relation between pairs of courses; the room constraint H2 is a relation among all the courses placed in a single slot. They interact because both limit what a slot can contain. H1 says that a slot may hold only mutually non-clashing courses (an independent set of G), while H2 says that it may hold at most two courses whose sizes fit the halls. A slot therefore holds at most two courses, and these two must be non-adjacent in the clash graph.")
    P("The consequence is that the colour classes of the timetable have size at most two. In graph terms, a timetable with k slots is a partition of the eight vertices into k independent sets of size at most two. Because there are eight exams and the classes hold at most two each, k ≥ 4, whatever the clash graph looks like. With exactly four slots, every slot must be completely full: every slot holds exactly two exams. This is a very strong restriction, and it explains why the search in Section 5 rejects candidates for 'no free hall' even when no clash exists. Table 4 summarises the interaction.")
    R.table(["Constraint", "Scope", "What it forbids", "Cost of checking one candidate"],
            [["H1 clash", "Pair of courses", "Two clashing courses in one slot", "O(deg(c)) neighbour look-ups"],
             ["H2 hall capacity", "One course, one hall", "Course larger than its hall", "O(1) comparison"],
             ["H2 one exam per hall per slot", "All courses in one slot", "A third exam in a slot, two exams in a hall", "O(1) counter check"],
             ["H3 exactly once", "Whole timetable", "Missing or duplicated exam", "Guaranteed by the search structure"]],
            [3.6, 3.3, 4.8, 4.2], "Interaction of the hard constraints")
    H2("3.2 Necessary Conditions that Prove Infeasibility Before Search")
    P("Several inexpensive conditions are necessary for a timetable with k slots. If any condition fails, no search is needed: the answer is NO.")
    B(["**N1 (room-slot count):** the number of room-slots k × h must be at least n, where h = 2 is the number of halls. Hence k ≥ ⌈n / h⌉ = ⌈ 8 / 2 ⌉ = 4.",
       "**N2 (total capacity):** the registrations must fit the seats: 720 ≤ k × (160 + 120) = 280k, giving k ≥ 3 (since 720 / 280 = 2.57).",
       "**N3 (clique bound):** a clique of size q in the clash graph needs q distinct slots. The largest clique is a triangle (q = 3), so k ≥ 3.",
       "**N4 (individual fit):** every course must fit in at least one hall: the largest enrolment is 150 (C5) ≤ 160, so this condition holds and C5 can only use Hall A."])
    R.table(["Condition", "Requirement", "Value for the data", "k = 3", "k = 4"],
            [["N1 room-slot count", "k × 2 ≥ 8", "k ≥ 4", "FAIL (6 < 8)", "Pass (8 ≥ 8)"],
             ["N2 total capacity", "280k ≥ 720", "k ≥ 3", "Pass (840 ≥ 720)", "Pass (1120 ≥ 720)"],
             ["N3 clique bound", "k ≥ ω(G)", "ω = 3", "Pass", "Pass"],
             ["N4 individual fit", "max n(c) ≤ 160", "150 ≤ 160", "Pass", "Pass"]],
            [3.6, 3.0, 3.0, 3.1, 3.2], "Necessary conditions for three and four slots", align_center_cols=(1, 2, 3, 4))
    P("Condition N1 alone proves that the examinations cannot be completed in three slots: three slots provide only six room-slots, while eight examinations must be placed (Figure 3). This is the pigeonhole principle, and it requires no clash information at all. It is worth noticing that N2 and N3, which look like the natural checks, both pass for k = 3; a planner who tested only seats and clashes would waste effort searching for a three-slot timetable that cannot exist.")
    R.figure(F("f03_pigeonhole"), "Pigeonhole argument: eight exams cannot occupy six room-slots", 11.5)
    H2("3.3 Order in Which Constraints Are Checked")
    P("During the search, each candidate (course, slot) pair is tested against the constraints in a fixed order, chosen so that the cheapest and most selective test comes first and an early failure avoids later work.")
    R.table(["Order", "Check", "Reason for its position"],
            [["0", "H3 and the static capacity test (N4)", "Done once, before search; H3 holds by construction because the search assigns exactly one slot to each course in turn."],
             ["1", "H1 clash with exams already in the slot", "Most selective test: it is the only test that depends on other courses' choices and it rejects most candidates early. Cost O(deg)."],
             ["2", "H2 free-hall test for the slot", "Needs the hall allocation of the slot after adding the course; run only when H1 has passed, because it is more expensive."],
             ["3", "S1 penalty (only in branch and bound)", "A bound-based test applied after hard feasibility is established; it never makes an infeasible candidate acceptable."]],
            [1.6, 5.2, 9.0], "Order of constraint checking during search", align_center_cols=(0,))
    H2("3.4 Order in Which Exams Are Scheduled")
    P("The order in which courses are assigned does not affect the correctness of backtracking but dramatically affects its speed. The principle is 'fail first': place the most constrained courses first so that dead ends appear near the root of the search tree, where cutting them off saves the most work. We rank courses by (i) the number of clashes (degree) in the clash graph, largest first, and (ii) in case of a tie, the larger enrolment first, since a large exam has fewer hall choices (C5 can use only Hall A). Table 7 gives the resulting order.")
    ranked = [[i + 1, c, DEG[c], SIZE[c], ", ".join(sorted(ADJ[c]))] for i, c in enumerate(ORDER)]
    R.table(["Rank", "Course", "Degree", "Students", "Neighbours"], ranked, [1.6, 2.0, 2.0, 2.4, 7.8], "Scheduling order (largest degree, then largest enrolment)", align_center_cols=(0, 1, 2, 3))
    P("The order is therefore C5, C1, C3, C6, C2, C8, C4, C7. The four degree-4 courses come first, and among them the descending enrolments 150, 120, 110 and 80 break ties. The two low-degree courses C4 and C7 come last because they clash with few others and can be placed almost anywhere, so they rarely cause failure. As a value-ordering rule, slots are tried in the natural order S1, S2, S3, S4, which also makes the trace reproducible.")
    H2("3.5 Symmetry")
    P("The slots S1 and S2 are interchangeable with respect to the hard constraints H1 to H3, and so are S3 and S4; only the day structure matters for the soft constraint. Any feasible timetable therefore has equivalent copies obtained by swapping colour names. The first course (C5) is always placed in S1; this is the usual symmetry-breaking step for colouring problems. In the exhaustive enumeration of Section 7 the symmetric copies are counted separately, which is why the number of feasible slot assignments is a multiple of the number of distinct timetables.")

    H1("4. Backtracking Solution Design")
    H2("4.1 Overview")
    P("Backtracking builds the timetable one course at a time, in the order fixed in Section 3.4. For the current course it tries each slot in turn. A slot is accepted only if H1 and H2 remain satisfied after the course is added; the algorithm then recurses to the next course. If the recursion fails, the assignment is undone and the next slot is tried. If all slots fail for a course, the procedure returns failure to its caller, which backtracks in turn. The search tree has depth 8 and at most four children per node, so it contains at most 4^8 leaves, but the constraint checks prune whole subtrees as soon as a partial assignment is infeasible.")
    H2("4.2 Data Structures")
    R.table(["Structure", "Content", "Purpose"],
            [["order[0..n-1]", "Courses in scheduling order", "Variable ordering (Section 3.4)"],
             ["size[c]", "Enrolment of course c", "Capacity checks"],
             ["adj[c]", "Set of courses clashing with c", "H1 check in O(deg)"],
             ["slotOf[c]", "Slot assigned to c, or NONE", "Current partial timetable"],
             ["exams[s]", "List of courses placed in slot s", "H2 check and hall allocation"],
             ["cap[1..h]", "Hall capacities sorted descending", "Room assignment test"],
             ["hallOf[c]", "Hall assigned to c", "Final timetable output"]],
            [3.4, 6.2, 6.0], "Data structures used by the algorithm")
    H2("4.3 Pseudocode")
    R.code("Algorithm 1: Backtrack(i), assign exams to slots one at a time", [
        (0, "**Backtrack**(i):"),
        (1, "if i = n then return TRUE                     // every exam scheduled (H3)"),
        (1, "e ← order[i]"),
        (1, "for each slot s in (S1, S2, ..., Sk) do"),
        (2, "if **ClashFree**(e, s) and **RoomFeasible**(e, s) then"),
        (3, "slotOf[e] ← s;  append e to exams[s]           // choose"),
        (3, "if **Backtrack**(i + 1) then return TRUE          // explore"),
        (3, "remove e from exams[s];  slotOf[e] ← NONE    // undo, backtrack"),
        (1, "return FALSE                                      // no slot works for e")])
    R.code("Algorithm 2: ClashFree(e, s), check hard constraint H1", [
        (0, "**ClashFree**(e, s):"),
        (1, "for each course x in adj[e] do"),
        (2, "if slotOf[x] = s then return FALSE                // a clashing exam is in s"),
        (1, "return TRUE")])
    R.code("Algorithm 3: RoomFeasible(e, s), check hard constraint H2", [
        (0, "**RoomFeasible**(e, s):"),
        (1, "L ← exams[s] ∪ {e}"),
        (1, "if |L| > h then return FALSE                      // more exams than halls"),
        (1, "sort L by size in descending order"),
        (1, "for j = 1 to |L| do"),
        (2, "if size[L[j]] > cap[j] then return FALSE         // j-th largest exam exceeds j-th largest hall"),
        (1, "return TRUE"),
        (0, "Main:  FOUND ← Backtrack(0);  if FOUND then output slotOf[] and the hall of each exam from Algorithm 3")])
    P("The three procedures together implement the full search. Algorithm 1 is the recursive skeleton: the loop chooses a value, the recursive call explores it, and the final assignments undo the choice if the call returned FALSE. Algorithm 2 enforces H1 and Algorithm 3 enforces H2. The call Backtrack(0) returns TRUE exactly when a complete feasible timetable exists and leaves it in slotOf[]. For the soft constraint the same skeleton is extended in Section 7.")
    R.figure(F("f04_flow_backtrack"), "Flowchart of the backtracking procedure", 11.0)
    H2("4.4 How a Room Assignment Within a Slot Is Checked")
    P("Inside one slot the halls are interchangeable except for their capacities, so the question is whether the list of exams in the slot can be matched to distinct halls with each exam fitting its hall. This is a bipartite matching with a nested structure: a hall of capacity c can take any exam of size at most c, so the sets of acceptable exams are nested. For nested sets, a greedy rule is optimal: sort the exams by size in descending order, sort the halls by capacity in descending order, and pair the j-th largest exam with the j-th largest hall. If any pair violates the capacity, no valid assignment exists.")
    P("The proof is a standard exchange argument. Suppose a valid assignment exists in which the largest exam x is not in the largest hall H1, so x is in hall Hj and some exam y occupies H1 (or H1 is free). Then size(x) ≤ cap(Hj) ≤ cap(H1), and size(y) ≤ size(x) ≤ cap(Hj), so swapping x and y keeps the assignment valid. Repeating the argument for the second largest exam shows that the sorted pairing is valid whenever any assignment is valid.")
    R.table(["Slot content", "Sorted exams", "Pairing (exam to hall)", "Result"],
            [["{C5, C2}", "C5 (150), C2 (90)", "C5 → A (160), C2 → B (120)", "Feasible"],
             ["{C1, C8}", "C1 (120), C8 (70)", "C1 → A (160), C8 → B (120)", "Feasible"],
             ["{C5, C1}", "C5 (150), C1 (120)", "C5 → A, C1 → B (120 ≤ 120)", "Feasible by capacity (but C5 and C1 clash)"],
             ["{C5, C2, C8}", "C5, C2, C8", "Three exams, two halls", "Infeasible: more exams than halls"],
             ["{C5}", "C5 (150)", "C5 → A (160)", "Feasible; Hall B left free"]],
            [3.0, 3.8, 5.2, 3.8], "Examples of the room-feasibility check")
    R.figure(F("f05_flow_room"), "Flowchart of the room-assignment test for one slot", 10.0)
    H2("4.5 Correctness")
    P("**Soundness.** A timetable is returned only after every course has passed ClashFree and RoomFeasible against the courses placed before it in its slot. Any clashing pair is therefore separated (H1: when the later course of the pair was placed, the earlier one was already in its slot, so the test would have rejected a common slot), every slot has a valid hall matching (H2), and every course is assigned exactly once because i advances by exactly one per successful assignment (H3).")
    P("**Completeness.** The search tries every slot for every course unless a constraint rejects it, and a rejection is permanent for that partial assignment because both constraints are monotone: adding more courses to a partial assignment can never repair a clash or free a hall. Hence if a feasible timetable exists, the branch leading to it is never pruned, and the procedure finds some feasible timetable; if it returns FALSE, none exists.")
    P("**Termination.** The recursion depth is at most n and each level loops over at most k slots, so the search tree is finite.")
    H2("4.6 Complexity of the Algorithm")
    P("In the worst case the algorithm explores O(k^n) nodes, since each of the n courses has k candidate slots. The work per node is O(deg + h log h) for the two checks. The space needed is O(n + |E|) for the data structures plus O(n) for the recursion stack. The worst case is exponential, as expected for an NP-Complete problem (Section 6), but the pruning makes the observed work far smaller (Section 6.5).")

    H1("5. Application to the Given Data")
    H2("5.1 Set-Up")
    P("The algorithm of Section 4 is run on the data of Section 2 with the order C5, C1, C3, C6, C2, C8, C4, C7 and slots tried in the order S1 to S4. The hall check uses the capacities 160 (A) and 120 (B). A 'candidate check' denotes one test of one course against one slot; each check ends in either a rejection (with its reason) or an assignment.")
    H2("5.2 Trace with Four Slots")
    rows = []
    for n, (dep, e, s, kind, why) in enumerate(log4, 1):
        if kind == "assign":
            res = f"ASSIGN. Halls in {s}: " + slot_rooms({x: sl for x, sl in a4.items() if x in [y for (dd, y, ss, kk, ww) in log4[:n] if kk == "assign" and ss == s]}, s) if False else None
        rows.append([n, dep + 1, e, s, "Assign" if kind == "assign" else ("Undo" if kind == "undo" else "Reject"), why if why else ("Passes H1 and H2" if kind == "assign" else "")])
    # attach hall info for assignments
    cur = {}
    for r_, (dep, e, s, kind, why) in zip(rows, log4):
        if kind == "assign":
            cur[e] = s; r_[5] = "Passes H1 and H2; " + slot_rooms({x: sl for x, sl in cur.items()}, s)
    R.table(["Step", "Level", "Exam", "Slot tried", "Action", "Reason / hall allocation"], rows, [1.2, 1.3, 1.5, 1.9, 1.8, 8.1],
            "Complete trace of the backtracking algorithm with four slots", size=10.5, align_center_cols=(0, 1, 2, 3, 4))
    P(f"The run consists of {st4['nodes']} candidate checks: 8 assignments and {st4['rejects']} rejections, with {st4['backtracks']} backtracks. Table 10 shows that the first row where H2 (rather than H1) causes a rejection is step 14 (C4 in S2): slot S2 already contains C1 and C8, so both halls are in use. The same reason rejects C7 in S1 at step 17: S1 already holds C5 and C2.")
    H2("5.3 Explanation of the Choices")
    B(["**C5 → S1.** The first course takes the first slot (symmetry breaking). C5 needs Hall A because 150 > 120.",
       "**C1.** Rejected in S1 because C1–C5 clash; accepted in S2.",
       "**C3.** Rejected in S1 (clash with C5) and S2 (clash with C1); accepted in S3.",
       "**C6.** Rejected in S1 (C5–C6) and S2 (C1–C6); accepted in S3, since C3 and C6 do not clash. S3 is now full (C3 in Hall A, C6 in Hall B).",
       "**C2.** Accepted in S1: C2 clashes with C1, C3 and C4 only, none of which is in S1. S1 is now full (C5 in Hall A, C2 in Hall B).",
       "**C8.** Rejected in S1 (C5–C8 clash); accepted in S2 (C8 does not clash with C1). S2 is now full.",
       "**C4.** S1 is rejected by the clash with C2, S2 by the lack of a free hall, and S3 by the clash with C6; S4 is accepted.",
       "**C7.** S1 has no free hall, S2 clashes with C8 and S3 clashes with C6, so C7 is placed in S4, completing the timetable."])
    P("No backtracking was needed because the ordering was effective: the most constrained courses were placed first, and at every level at least one slot remained feasible. To show the undo operation in action, Section 5.5 examines the case of three slots, where backtracking is unavoidable.")
    R.figure(F("f06_search_tree"), "Search progress for four slots: rejected and accepted slots for each exam", 12.5)
    H2("5.4 Resulting Four-Slot Timetable")
    rows = []
    for s in SLOTS:
        ex = sorted([e for e in a4 if a4[e] == s], key=lambda c: -SIZE[c])
        rows.append([s, "Day %d %s" % (DAY[s], "FN" if s in ("S1", "S3") else "AN")] + [f"{e} ({SIZE[e]})" for e in ex])
    R.table(["Slot", "Session", "Hall A (160)", "Hall B (120)"], rows, [2.0, 3.6, 5.0, 5.0], "Timetable produced by backtracking (feasible, not yet optimised)", align_center_cols=(0, 1, 2, 3))
    R.figure(F("f07_timetable_first"), "The four-slot timetable with halls", 13.0)
    R.figure(F("f08_colored_graph"), "Clash graph coloured by slot (adjacent vertices have different slots)", 8.8)
    P("The vertex shades in Figure 8 show a proper colouring: no edge joins two vertices of the same shade. Table 12 verifies each of the 13 clash constraints explicitly.")
    rows = [[f"{a}–{b}", a4[a], a4[b], "Different slots" if a4[a] != a4[b] else "CLASH"] for a, b in CLASH_PAIRS]
    R.table(["Clashing pair", "Slot of first", "Slot of second", "H1 verdict"], rows, [3.6, 3.6, 3.6, 4.8], "Verification of H1 for every clashing pair", align_center_cols=(0, 1, 2, 3))
    rows = [[s, slot_rooms(a4, s), sum(SIZE[e] for e in a4 if a4[e] == s)] for s in SLOTS]
    R.table(["Slot", "Exams and halls", "Total candidates"], rows, [2.0, 9.6, 4.0], "Verification of H2 and H3 (every exam appears exactly once)", align_center_cols=(0, 2))
    P("All eight exams appear exactly once, each hall hosts at most one exam per slot, and every exam fits its hall (Hall A: C5 150, C1 120, C3 110 and C4 60, all ≤ 160; Hall B: C2 90, C8 70, C6 80 and C7 40, all ≤ 120). The same-day penalty of this timetable is " + str(penalty(a4)) + ": Day 1 contains the clashing pairs C1–C2, C1–C5 and C5–C8, and Day 2 contains C4–C6 and C6–C7. It is feasible but not yet optimal; Section 7 improves it.")
    H2("5.5 Can the Examinations Be Completed in Three Slots?")
    P("**No.** The justification has three parts.")
    B(["**Counting argument (proof before search).** Three slots offer 3 × 2 = 6 room-slots, but 8 examinations must be placed, and each room-slot holds one examination (H2). This is the pigeonhole principle and settles the question without examining the clashes.",
       "**It is not a clash problem.** Ignoring rooms, the clash graph can be coloured with three colours (the clique number is 3), so the clash constraint alone does not prevent a three-slot timetable. The blocking constraint is H2: the interaction of H1 and H2 described in Section 3.1.",
       f"**Search confirms it.** Running the algorithm with slots S1 to S3 only returns FALSE after {st3['nodes']} candidate checks, {st3['rejects']} rejections and {st3['backtracks']} backtracks (the complete trace is in Appendix A). The deepest level reached is {maxdepth3}: only {maxdepth3} of the 8 courses can ever be placed together, never all eight."])
    P(f"An illustration of the undo operation from Appendix A: the search places C5, C1, C3, C6 and C2 in turn, then C8, and tries the next courses; when C4 or C7 cannot be placed, control returns to the previous level, the last assignment is removed ('Undo') and the next slot is tried for that earlier course. Every alternative eventually fails, and after the root course C5 has exhausted its slots the procedure reports FAILURE. The search reaches this verdict after {st3['nodes']} checks, far fewer than the 3^8 = 6,561 assignments of the full three-slot space.")

    H1("6. Complexity Classification")
    H2("6.1 The Decision Version is in NP")
    P("A problem is in NP if a proposed solution (a certificate) can be verified in polynomial time. For TIMETABLE-FEASIBILITY the certificate is the proposed timetable: the slot and the hall of each course. It is verified as follows.")
    R.code("Algorithm 4: Verify(τ), polynomial-time verifier", [
        (0, "**Verify**(slot[], hall[]):"),
        (1, "for each course c do   // H3: defined exactly once"),
        (2, "if slot[c] ∉ T or hall[c] ∉ H then return FALSE"),
        (2, "if size[c] > cap[hall[c]] then return FALSE         // H2 capacity"),
        (1, "for each pair {a, b} in E do"),
        (2, "if slot[a] = slot[b] then return FALSE             // H1 clash"),
        (1, "for each course pair a < b do"),
        (2, "if slot[a] = slot[b] and hall[a] = hall[b] then return FALSE   // H2 hall used once"),
        (1, "return TRUE")])
    P("The cost of verification is O(n) for the first loop, O(|E|) for the clash loop and O(n^2) for the hall-sharing loop (reducible to O(n) with a table indexed by (slot, hall)). The total is O(n + |E|) with the table, or O(n^2) in the simplest implementation; both are polynomial in the input size. For the given data this means 8 + 13 + 28 = 49 elementary tests. Hence TIMETABLE-FEASIBILITY ∈ NP.")
    H2("6.2 The Decision Version is NP-Hard")
    P("NP-hardness is shown by reduction from GRAPH k-COLOURING (for k = 3), which is NP-Complete (Karp, 1972). Given a graph G = (V, E) and an integer k, construct a timetabling instance in polynomial time as follows.")
    B(["One course for each vertex, with enrolment 1.",
       "A clash between two courses exactly when the corresponding vertices are adjacent in G.",
       "k examination slots.",
       "|V| halls in each slot, each of capacity at least 1, so that the room constraint H2 can never fail."])
    P("The construction is clearly polynomial. If G has a proper k-colouring, assign each colour class to one slot and give each course in a slot a distinct hall; H1 holds because adjacent vertices have different colours, H2 holds because there are as many halls as courses, and H3 holds by construction. Conversely, if a feasible timetable exists, define the colour of a vertex as the slot of its course; H1 makes it a proper colouring with at most k colours. Hence G is k-colourable if and only if the timetable instance is feasible, and the decision version is NP-Hard.")
    P("**A remark on the number of halls.** The reduction above lets the number of halls per slot grow with the input, as it does at a large university with many halls. If the number of halls is fixed at two, as in the present instance, each slot holds at most two exams and the feasibility question for k slots can be decided in polynomial time by a maximum matching in the complement of the clash graph restricted to size-compatible pairs. The brief's instance therefore belongs to an easy special case, but the question the Controller of Examinations asks, how hard the problem becomes as the number of courses grows, concerns the general problem, whose hardness lies in graph colouring itself. This distinction is important and is why the general problem is the one classified here.")
    H2("6.3 NP-Completeness")
    P("Combining Sections 6.1 and 6.2, the decision version of the general timetabling problem is both in NP and NP-Hard, so it is **NP-Complete** (Figure 9). No polynomial-time algorithm is known for it, and one would imply P = NP. This is consistent with the observed behaviour: the worst-case running time of backtracking is exponential in the number of courses.")
    R.figure(F("f15_classes"), "Complexity classes and the position of the timetabling problems", 11.0)
    H2("6.4 Classification of the Optimisation Version")
    P("The optimisation version, minimising the number of same-day clashes, is **NP-Hard**. It is not itself in NP, because NP is a class of decision problems, but its decision form (is there a feasible timetable with penalty at most K?) is NP-Complete. It is in NP because a timetable can be verified by Algorithm 4 and its penalty counted in O(|E|) time. It is NP-Hard because it generalises the feasibility problem: a feasible timetable exists exactly when the minimum is finite. Hardness holds even without the hard constraints, as the following argument shows. With n slots on each of the two days and n halls per slot, H1 to H3 are always satisfiable (each exam alone in a slot) and the objective reduces to splitting the courses into two day-groups so as to minimise the clashes inside the groups, which is exactly the MAX-CUT problem (the clashes not inside a group form a cut). MAX-CUT is NP-Hard (Karp, 1972), so the optimisation version is NP-Hard.")
    R.table(["Problem", "Decision / optimisation", "In NP?", "Classification"],
            [["Timetable feasibility (k slots)", "Decision", "Yes (verifier in O(n + |E|))", "NP-Complete"],
             ["Timetable with penalty ≤ K", "Decision", "Yes", "NP-Complete"],
             ["Minimise same-day clashes", "Optimisation", "Not a decision problem", "NP-Hard"],
             ["Verify a given timetable", "Decision", "Yes", "P (linear time)"],
             ["Two halls only, minimum slots", "Optimisation", "Yes (matching)", "P (special case)"]],
            [5.0, 3.4, 4.2, 3.0], "Complexity classification of the problem variants")
    H2("6.5 Search-Space Size versus Work Performed")
    P("The full search space has 4^8 = 65,536 slot assignments (each of eight courses in one of four slots). If halls are also chosen freely, it has 8^8 = 16,777,216 (slot, hall) assignments. A complete enumeration of the slot assignments shows that exactly " + str(len(sols)) + " of the 65,536 satisfy H1, H2 and H3 (symmetric copies counted separately), i.e. 0.33 percent. Table 15 and Figure 10 compare these numbers with the work done by the pruned search.")
    R.table(["Quantity", "Count", "Share of 65,536"],
            [["All slot assignments, 4^8", "65,536", "100 %"], ["All (slot, hall) assignments, 8^8", "16,777,216", "25,600 %"],
             ["Feasible slot assignments (exhaustive)", str(len(sols)), f"{100 * len(sols) / 65536:.2f} %"],
             ["Backtracking, four slots (candidate checks)", str(st4["nodes"]), f"{100 * st4['nodes'] / 65536:.3f} %"],
             ["Backtracking, three slots (candidate checks, proof of infeasibility)", str(st3["nodes"]), "n/a (3^8 = 6,561 space)"],
             ["Branch and bound (candidate checks, proves optimality)", str(bb["nodes"]), f"{100 * bb['nodes'] / 65536:.2f} %"]],
            [9.0, 3.2, 3.4], "Search-space size compared with the work performed", align_center_cols=(1, 2))
    R.figure(F("f10_search_space"), "Full search space compared with the work performed (log scale)", 11.0)
    P(f"Finding a feasible timetable needed only {st4['nodes']} candidate checks, about 0.03 percent of the slot-assignment space, because every rejection removes a whole subtree: for example, rejecting C1 in S1 at level 2 discards all 4^6 = 4,096 completions of that choice. Proving optimality with branch and bound needed {bb['nodes']} checks, about 1 percent of the space.")
    H2("6.6 Growth with the Number of Courses")
    P("The worst-case size of the search space grows as k^n. Table 16 shows how fast this explodes; even with pruning the effort grows exponentially for hard instances, which is the answer to the Controller's question about how difficult the problem becomes as the number of courses grows.")
    rows = []
    for n_, k_ in ((8, 4), (10, 4), (15, 5), (20, 6), (30, 8), (50, 10), (100, 15), (300, 30)):
        v = k_ ** n_; rows.append([n_, k_, f"{v:,}" if v < 10**12 else sci(v)])
    R.table(["Courses n", "Slots k", "Search space k^n"], rows, [3.4, 3.4, 8.8], "Worst-case search-space growth", align_center_cols=(0, 1, 2))
    R.figure(F("f12_growth"), "Exponential growth versus polynomial growth", 10.5)
    P("For 300 courses and 30 slots, the space has about 10^443 candidates; at a billion checks per second, an exhaustive search would take far longer than the age of the universe. Exact search is therefore restricted to small instances, and Section 8 describes the practical alternative.")

    H1("7. Improvement Using Branch and Bound")
    H2("7.1 Objective")
    P("The backtracking timetable of Section 5.4 has penalty 5. We now use branch and bound to find a timetable that satisfies all hard constraints and minimises the penalty of the soft constraint S1. Branch and bound is backtracking with an additional pruning rule driven by the best solution found so far.")
    H2("7.2 Design")
    B(["**Branching:** the same as backtracking: the exams in the order of Section 3.4, slots S1 to S4, with H1 and H2 checked first.",
       "**Incremental cost:** when exam e is placed in slot s, the added penalty is the number of already-placed clashing neighbours whose slot lies on the same day as s. Penalty never decreases along a path, because later assignments can only add clashes.",
       "**Bound:** the partial penalty is a valid lower bound on the penalty of every completion. If it is greater than or equal to the best penalty already found, the whole subtree is pruned (it cannot yield a strictly better timetable).",
       "**Incumbent:** the first leaf reached is the first timetable of Section 5.4 (penalty 5); each improvement replaces the incumbent."])
    R.code("Algorithm 5: Branch and bound for the soft constraint S1", [
        (0, "best ← ∞;  bestTimetable ← NONE"),
        (0, "**BB**(i, pen):"),
        (1, "if pen ≥ best then return                          // bound: cannot improve"),
        (1, "if i = n then best ← pen;  bestTimetable ← copy of slotOf;  return"),
        (1, "e ← order[i]"),
        (1, "for each slot s in (S1, S2, S3, S4) do"),
        (2, "if not ClashFree(e, s) or not RoomFeasible(e, s) then continue   // hard constraints"),
        (2, "add ← number of x in adj[e] with slotOf[x] ≠ NONE and day(slotOf[x]) = day(s)"),
        (2, "slotOf[e] ← s;  append e to exams[s]"),
        (2, "**BB**(i + 1, pen + add)"),
        (2, "remove e from exams[s];  slotOf[e] ← NONE        // undo"),
        (0, "Main: BB(0, 0); output bestTimetable and best")])
    R.figure(F("f13_flow_bb"), "Flowchart of the branch-and-bound extension", 11.0)
    H2("7.3 Application")
    imps = bb["improve"]
    rows = [[i + 1, p_, ", ".join(f"{s}: {', '.join(sorted(e for e in a_ if a_[e] == s))}" for s in SLOTS)] for i, (p_, a_) in enumerate(imps)]
    R.table(["Improvement", "Penalty", "Timetable (slot: exams)"], rows, [2.8, 2.2, 10.6], "Sequence of incumbents found by branch and bound", align_center_cols=(0, 1))
    P(f"The search starts with the penalty-{imps[0][0]} timetable of Section 5.4 and improves it twice, to {imps[1][0]} and then to {imps[2][0]}. After the last improvement, the remaining search is only needed to prove that nothing better exists. The statistics are: {bb['nodes']} candidate checks, {bb['pruned_hard']} rejected by the hard constraints, {bb['pruned_bound']} subtrees pruned by the bound and {bb['leaves']} complete timetables reached. The bound pruning removed subtrees that would otherwise have been expanded, so the exact optimum is obtained with about 1 percent of the 65,536-assignment space.")
    H2("7.4 Best Timetable and Its Penalty")
    rows = []
    for s in SLOTS:
        ex = sorted([e for e in BA if BA[e] == s], key=lambda c: -SIZE[c])
        rows.append([s, "Day %d %s" % (DAY[s], "FN" if s in ("S1", "S3") else "AN")] + [f"{e} ({SIZE[e]})" for e in ex])
    R.table(["Slot", "Session", "Hall A (160)", "Hall B (120)"], rows, [2.0, 3.6, 5.0, 5.0], "Best timetable found by branch and bound (penalty 3)", align_center_cols=(0, 1, 2, 3))
    R.figure(F("f09_timetable_best"), "Optimal timetable with halls (penalty 3)", 13.0)
    same = [(a, b) for a, b in CLASH_PAIRS if DAY[BA[a]] == DAY[BA[b]]]
    rows = [[f"Day {dd}", ", ".join(sorted(e for e in BA if DAY[BA[e]] == dd)), ", ".join(f"{a}–{b}" for a, b in same if DAY[BA[a]] == dd) or "None",
             sum(1 for a, b in same if DAY[BA[a]] == dd)] for dd in (1, 2)]
    R.table(["Day", "Exams on the day", "Clashing pairs on the same day", "Count"], rows, [2.0, 5.8, 5.8, 2.0], "Same-day clashes of the best timetable", align_center_cols=(0, 3))
    P("The best timetable has penalty 3: C1 and C5 write on Day 1, and C3 meets C2 and C8 on Day 2. Each of the other ten clashing pairs is separated by day. The timetable is also feasible for H1 to H3: each slot holds two non-clashing courses, the larger in Hall A and the smaller in Hall B (C5 150 ≤ 160 in S1, C1 120 ≤ 160 in S2, C3 110 ≤ 160 in S3, C2 90 ≤ 160 in S4, with C4 60, C7 40, C6 80 and C8 70 all ≤ 120).")
    R.figure(F("f16_best_graph"), "Clash graph of the best timetable: bold edges are the same-day clashes", 8.8)
    H2("7.5 Justification of Correctness and Optimality")
    P("**Feasibility.** Every leaf of the branch-and-bound search is a complete assignment that passed ClashFree and RoomFeasible at each step, so the returned timetable satisfies H1, H2 and H3 exactly as in Section 4.5.")
    P("**Optimality.** The bound only discards a node when its partial penalty is at least the incumbent value. Since the partial penalty is a lower bound on the penalty of every completion (penalties are non-negative and only added), a discarded subtree cannot contain a timetable with a strictly smaller penalty. All other nodes are explored, so when the search terminates the incumbent is optimal.")
    P("**An independent lower bound.** The result can also be proved by hand. The graph contains three triangles that share no edge: {C1, C2, C3}, {C1, C5, C6} and {C3, C5, C8}. The three courses of a triangle clash with one another and must therefore occupy three different slots; but there are only two days, so by the pigeonhole principle two of the three courses are on the same day. Each triangle therefore contributes at least one same-day clashing pair, and since the triangles are edge-disjoint these pairs are distinct. Hence every feasible timetable has penalty at least 3, and the timetable of Table 18 attains it.")
    P("**Cross-check.** An exhaustive enumeration of all 65,536 slot assignments finds " + str(len(sols)) + " feasible assignments, whose penalties are distributed as in Table 20 and Figure 15. The minimum is 3, in agreement with both the branch-and-bound result and the hand-made lower bound.")
    R.table(["Penalty", "Feasible slot assignments", "Share"], [[k, dist[k], f"{100 * dist[k] / len(sols):.1f} %"] for k in sorted(dist)] + [["Total", len(sols), "100 %"]],
            [3.0, 6.0, 4.0], "Distribution of the penalty over all feasible slot assignments", align_center_cols=(0, 1, 2), bold_last=True)
    R.figure(F("f11_penalty_dist"), "Number of feasible timetables for each penalty value", 9.5)

    H1("8. Scaling to 300 Courses")
    H2("8.1 Why Exact Search Fails")
    P("With 300 courses the number of clashing pairs may run into thousands, and the number of slots may be around 30 to 40 over two or three weeks. As Section 6.6 shows, the search space is about 10^443. Pruning does not rescue exact search: the problem is NP-Complete, and real student-course data produces dense clash graphs with many near-ties. A complete search could not even prove infeasibility in reasonable time. The Controller therefore needs a method that produces a good, valid timetable quickly, without a guarantee of optimality, and that can be re-run when registrations change.")
    H2("8.2 Proposed Hybrid Method")
    R.figure(F("f14_pipeline"), "Proposed pipeline for 300 courses", 10.0)
    R.numbered(["**Pre-processing and bounds.** Compute degrees, a maximal clique and the room-slot bound of Section 3.2. These give a lower bound on the number of slots and detect an impossible request early.",
                "**Constructive heuristic (DSATUR).** Colour the clash graph with the saturation-degree heuristic (Brélaz, 1979): repeatedly pick the course whose neighbours already use the most distinct slots, and give it the first feasible slot. This is the 'fail first' idea of Section 3.4 made dynamic, and it runs in O(n^2).",
                "**Room allocation.** For each slot, assign courses to halls with the sorted pairing of Section 4.4 generalised to many halls (best-fit decreasing bin packing, or a bipartite matching), and move a course to another slot when a slot overflows.",
                "**Repair with Kempe chains.** If the construction needs too many slots or violates H2, swap the two slots of a connected two-slot subgraph (a Kempe chain); this preserves H1 while changing the load of the slots.",
                "**Local search for the soft constraints.** Use simulated annealing or tabu search with moves 'shift one exam to another slot' and 'swap two exams', evaluated by a weighted cost (hard violations with a large weight, same-day or consecutive-slot clashes with small weights). Because the evaluation of a move only touches the neighbours of the moved course, each step costs O(deg).",
                "**Exact polishing.** Apply the branch and bound of Section 7, or a CP-SAT / integer-programming solver, to small windows (for instance the 10 to 15 courses of one slot-pair) while the rest is fixed. This recovers optimality locally.",
                "**Validation.** Run the verifier of Algorithm 4 (linear time) on the final timetable before publication."])
    H2("8.3 Comparison of Approaches")
    R.table(["Approach", "Guarantee", "Time for 300 courses", "Suitability"],
            [["Plain backtracking", "Complete and exact", "Exponential, impractical", "Only up to about 15 to 20 courses"],
             ["Branch and bound with strong bounds", "Optimal", "Exponential in worst case", "Sub-problems and small departments"],
             ["Greedy / DSATUR colouring", "Feasible, not optimal", "Milliseconds", "Starting solution"],
             ["Simulated annealing / tabu search", "Good, no proof", "Seconds to minutes", "Main optimiser for soft constraints"],
             ["ILP / CP-SAT", "Optimal if finishes", "Minutes to hours", "Polishing, verifying bounds"],
             ["Hybrid pipeline (proposed)", "Always valid, near-optimal", "Seconds to minutes", "Recommended for 300 courses"]],
            [4.6, 3.6, 3.6, 3.8], "Comparison of approaches for large instances")
    H2("8.4 Quality Measures and Practical Considerations")
    B(["**Measures:** number of hard violations (must be 0), same-day clashes, students with consecutive-slot papers, number of slots used, hall utilisation.",
       "**Decomposition:** schedule by department or year in batches, since clashes between unrelated programmes are rare; the clash graph is then sparse across batches.",
       "**Incrementality:** keep the previous timetable and repair only the neighbourhood of a changed registration.",
       "**Determinism and fairness:** fix a random seed and publish the cost breakdown so that the Controller can reproduce and defend the timetable.",
       "**Fallback:** if the pre-processing bound shows that the available slots are too few, report the shortfall (for example, extra halls or an extra day needed) instead of searching."])

    H1("9. Verification, Discussion and Rubric Mapping")
    H2("9.1 Summary of Results")
    R.table(["Item", "Result"],
            [["Courses / registrations", "8 / 720 students"], ["Clashing pairs", "13 (3 edge-disjoint triangles)"], ["Minimum slots (necessary condition N1)", "4"],
             ["Three slots possible?", "No (6 room-slots < 8 exams; search: " + str(st3["nodes"]) + " checks, " + str(st3["backtracks"]) + " backtracks)"],
             ["Backtracking effort, four slots", f"{st4['nodes']} checks, {st4['rejects']} rejections, {st4['backtracks']} backtracks"],
             ["First timetable penalty", str(penalty(a4))], ["Best timetable penalty (branch and bound)", "3 (proved optimal)"],
             ["Optimal / feasible slot assignments", f"{dist[3]} optimal of {len(sols)} feasible, out of 65,536"],
             ["Complexity: decision / optimisation", "NP-Complete / NP-Hard"]],
            [6.6, 9.0], "Summary of the principal results")
    H2("9.2 Validation")
    P("Three independent checks support the results. First, the verifier of Algorithm 4 was run on the final timetables and accepted both. Second, an exhaustive enumeration of all 65,536 slot assignments confirmed the number of feasible timetables and the minimum penalty. Third, the lower bound of 3 was derived by hand from edge-disjoint triangles (Section 7.5). The agreement of the three confirms the correctness of the implementation and of the analysis.")
    H2("9.3 Limitations")
    B(["The model treats the two sessions of a day as equally burdensome and does not penalise consecutive slots; a weighted penalty can be added without changing the algorithms.",
       "Hall capacities are taken as seating limits only; invigilator availability, special seating and hall locations are not modelled.",
       "With only two halls per slot, the pure feasibility problem is polynomial (Section 6.2); the NP-Completeness result concerns the general problem with arbitrarily many halls.",
       "The heuristic method for 300 courses offers no optimality guarantee, only a validated feasible timetable."])
    H2("9.4 Mapping to the Assessment Rubric")
    R.table(["Criterion (weight)", "Where addressed", "Evidence"],
            [["Problem understanding (25%)", "Sections 2, 3.1", "Input, variables, domains, H1 to H3, S1, decision and optimisation versions, graph colouring"],
             ["Constraint analysis (25%)", "Section 3", "Interaction of H1 and H2, necessary conditions N1 to N4, checking order, exam ordering"],
             ["Solution development (25%)", "Sections 4, 5, 7", "Pseudocode, trace, feasible timetable, optimal timetable, penalty 3"],
             ["Application of concepts (15%)", "Sections 5, 6, 8", "Backtracking, branch and bound, NP-Completeness, heuristics for 300 courses"],
             ["Justification (10%)", "Sections 3.4, 4.5, 6, 7.5", "Fail-first ordering, correctness proofs, reduction, lower-bound argument"]],
            [4.4, 3.4, 7.8], "Mapping of the report to the rubric")

    H1("10. Conclusion")
    P("The examination timetabling problem was formalised as a constraint satisfaction problem and related to graph colouring. A simple counting argument showed that three slots cannot hold eight examinations in two halls, and the backtracking algorithm confirmed this and found a feasible four-slot timetable in 20 candidate checks without any backtracking, using a fail-first ordering. Branch and bound improved the timetable from five same-day clashes to the optimal three, and a hand proof based on edge-disjoint triangles showed that three is the minimum. The decision version of the general problem is NP-Complete and its optimisation version NP-Hard, which explains why the exhaustive method does not scale: for 300 courses the search space is about 10^443. For such sizes, a pipeline of DSATUR colouring, room allocation, Kempe-chain repair, local search and exact polishing gives a valid timetable in seconds. The accompanying code reproduces every number in this report.")
    H1("References")
    R.numbered(["M. R. Garey and D. S. Johnson, Computers and Intractability: A Guide to the Theory of NP-Completeness. W. H. Freeman, 1979.",
                "R. M. Karp, 'Reducibility among combinatorial problems', in Complexity of Computer Computations, Plenum Press, 1972, pp. 85–103.",
                "T. H. Cormen, C. E. Leiserson, R. L. Rivest and C. Stein, Introduction to Algorithms, 4th ed. MIT Press, 2022.",
                "S. Russell and P. Norvig, Artificial Intelligence: A Modern Approach, 4th ed. Pearson, 2021.",
                "D. Brélaz, 'New methods to color the vertices of a graph', Communications of the ACM, vol. 22, no. 4, pp. 251–256, 1979.",
                "M. W. Carter, G. Laporte and S. Y. Lee, 'Examination timetabling: algorithmic strategies and applications', Journal of the Operational Research Society, vol. 47, pp. 373–383, 1996.",
                "R. Qu, E. K. Burke, B. McCollum, L. T. G. Merlot and S. Y. Lee, 'A survey of search methodologies and automated system development for examination timetabling', Journal of Scheduling, vol. 12, pp. 55–89, 2009.",
                "A. Levitin, Introduction to the Design and Analysis of Algorithms, 3rd ed. Pearson, 2012."])

    H1("Appendix A: Complete Trace with Three Slots")
    P("The table lists every candidate check of the algorithm restricted to slots S1, S2 and S3. 'Undo' marks the removal of an earlier assignment during backtracking. The search ends with FAILURE.")
    rows = []
    for n, (dep, e, s, kind, why) in enumerate(log3, 1):
        rows.append([n, dep + 1, e, s, {"assign": "Assign", "undo": "Undo", "reject": "Reject"}[kind], why or ("Passes H1 and H2" if kind == "assign" else "")])
    R.table(["Step", "Level", "Exam", "Slot", "Action", "Reason"], rows, [1.3, 1.4, 1.5, 1.5, 1.9, 8.0], "Complete three-slot trace (result: FAILURE)", size=10.5, align_center_cols=(0, 1, 2, 3, 4))
    H1("Appendix B: Implementation and ZIP Contents")
    P("The Python code that produced all results is supplied in the ZIP file. It uses only the Python standard library, apart from the figure and report generators.")
    R.table(["File", "Purpose"],
            [["solver.py", "Data, backtracking, room check, branch and bound, exhaustive verification"], ["make_figures.py", "Generates all figures (matplotlib)"],
             ["docx_lib.py", "Word formatting helpers (python-docx)"], ["build_report.py", "Builds this Word document from the computed results"],
             ["Examination_Timetabling_Report.docx", "This report"], ["README.txt", "Instructions to run the code"]],
            [6.0, 9.6], "Contents of the ZIP file")
    return R

# ---------------- two-pass build with TOC page numbers ----------------
def toc_from_headings(R): return [h for h in R.heads]
TOC_HEADS = []
toc = {}
R0 = None
# pass 0: discover headings (placeholder TOC has to exist, so run twice)
TOC_HEADS = [(1, "x")]
R0 = build({}); TOC_HEADS = toc_from_headings(R0)
for _ in range(2):
    R1 = build(toc); R1.d.save("Examination_Timetabling_Report.docx")
    subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "Examination_Timetabling_Report.docx"], capture_output=True)
    txt = subprocess.run(["pdftotext", "-layout", "Examination_Timetabling_Report.pdf", "-"], capture_output=True, text=True).stdout
    pages = [re.sub(r"\s+", " ", p) for p in txt.split("\f")]
    first = TOC_HEADS[0][1]
    body_start = max(i for i, p in enumerate(pages) if first in p)
    cur = body_start; toc = {}
    for lvl, h in TOC_HEADS:
        hh = re.sub(r"\s+", " ", h)
        for i in range(cur, len(pages)):
            if hh in pages[i]: cur = i; toc[h] = i - body_start + 1; break
    print("pages total", len(pages) - 1, "body starts at", body_start + 1)
